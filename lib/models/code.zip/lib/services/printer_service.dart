import 'package:flutter/foundation.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/printer_device.dart';
import 'dart:convert';

class PrinterService with ChangeNotifier {
  BluetoothConnection? _connection;
  PrinterDevice? _connectedPrinter;
  bool _isConnecting = false;
  bool _isConnected = false;
  String? _errorMessage;

  // Getters
  PrinterDevice? get connectedPrinter => _connectedPrinter;
  bool get isConnected => _isConnected;
  bool get isConnecting => _isConnecting;
  String? get errorMessage => _errorMessage;

  PrinterService() {
    _loadSavedPrinter();
  }

  // Load previously paired printer from shared preferences
  Future<void> _loadSavedPrinter() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final printerJson = prefs.getString('saved_printer');
      if (printerJson != null) {
        _connectedPrinter = PrinterDevice.fromJson(jsonDecode(printerJson));
        print('[v0] Loaded saved printer: ${_connectedPrinter?.name}');
        notifyListeners();
      }
    } catch (e) {
      print('[v0] Error loading saved printer: $e');
    }
  }

  // Get all available Bluetooth devices
  Future<List<BluetoothDevice>> getAvailableDevices() async {
    try {
      _errorMessage = null;
      final List<BluetoothDevice> devices = (await FlutterBluetoothSerial.instance.getBondedDevices()).cast<BluetoothDevice>();
      print('[v0] Found ${devices.length} bonded devices');
      return devices;
    } catch (e) {
      _errorMessage = 'Failed to get devices: $e';
      print('[v0] Error getting devices: $e');
      notifyListeners();
      return [];
    }
  }

  // Connect to a specific printer device
  Future<bool> connectToDevice(BluetoothDevice device) async {
    try {
      _isConnecting = true;
      _errorMessage = null;
      notifyListeners();

      print('[v0] Connecting to printer: ${device.name}');

      // Disconnect if already connected
      if (_connection != null && _isConnected) {
        await _connection?.close();
      }

      // Connect to the device
      _connection = await BluetoothConnection.toAddress(device.address);
      
      _isConnected = true;
      _isConnecting = false;
      
      // Save printer to local storage
      _connectedPrinter = PrinterDevice(
        id: device.address,
        name: device.name ?? 'Unknown',
        address: device.address,
        pairedAt: DateTime.now(),
      );

      await _savePrinterLocally(_connectedPrinter!);
      
      print('[v0] Successfully connected to ${device.name}');
      notifyListeners();
      return true;
    } catch (e) {
      _isConnecting = false;
      _isConnected = false;
      _errorMessage = 'Connection failed: $e';
      print('[v0] Connection error: $e');
      notifyListeners();
      return false;
    }
  }

  // Save printer to shared preferences
  Future<void> _savePrinterLocally(PrinterDevice printer) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('saved_printer', jsonEncode(printer.toJson()));
      print('[v0] Saved printer: ${printer.name}');
    } catch (e) {
      print('[v0] Error saving printer: $e');
    }
  }

  // Test print to verify connection
  Future<bool> testPrint() async {
    if (!_isConnected || _connection == null) {
      _errorMessage = 'Not connected to printer';
      notifyListeners();
      return false;
    }

    try {
      print('[v0] Sending test print...');
      
      final List<int> testPrintData = [
        0x1B, 0x40, // Initialize printer
        0x1B, 0x61, 0x01, // Center alignment
        0x1B, 0x45, 0x01, // Bold on
        ...utf8.encode('TEST PRINT\n'),
        0x1B, 0x45, 0x00, // Bold off
        0x0A, 0x0A, // Line breaks
        0x1B, 0x69, // Cut paper
      ];

      _connection!.output.add(Uint8List.fromList(testPrintData));
      await Future.delayed(const Duration(milliseconds: 500));
      
      print('[v0] Test print sent successfully');
      return true;
    } catch (e) {
      _errorMessage = 'Test print failed: $e';
      print('[v0] Test print error: $e');
      notifyListeners();
      return false;
    }
  }

  // Print invoice data to thermal printer (58mm format)
  Future<bool> printInvoice({
    required String storeName,
    required String customerName,
    required String mobileNumber,
    required String paymentMethod,
    required List<Map<String, dynamic>> items,
    required double totalAmount,
    required String invoiceNumber,
    required String printDate,
  }) async {
    if (!_isConnected || _connection == null) {
      _errorMessage = 'Not connected to printer';
      notifyListeners();
      return false;
    }

    try {
      print('[v0] Printing invoice to thermal printer...');
      
      List<int> printData = [];

      // Initialize printer
      printData.addAll([0x1B, 0x40]);

      // Store header - centered, bold, large
      printData.addAll([0x1B, 0x61, 0x01]); // Center
      printData.addAll([0x1B, 0x45, 0x01]); // Bold on
      printData.addAll([0x1D, 0x21, 0x21]); // Double width & height
      printData.addAll(utf8.encode(storeName));
      printData.addAll(utf8.encode('\n'));
      printData.addAll([0x1D, 0x21, 0x00]); // Reset size
      printData.addAll([0x1B, 0x45, 0x00]); // Bold off

      // Separator line
      printData.addAll(utf8.encode('===============================\n'));

      // Invoice details - left aligned
      printData.addAll([0x1B, 0x61, 0x00]); // Left align

      // Customer info
      printData.addAll(utf8.encode('Invoice: $invoiceNumber\n'));
      printData.addAll(utf8.encode('Date: $printDate\n'));
      printData.addAll(utf8.encode('\n'));
      printData.addAll(utf8.encode('Customer: $customerName\n'));
      printData.addAll(utf8.encode('Mobile: $mobileNumber\n'));
      printData.addAll(utf8.encode('Payment: $paymentMethod\n'));

      // Separator
      printData.addAll(utf8.encode('===============================\n'));

      // Table header
      printData.addAll([0x1B, 0x45, 0x01]); // Bold on
      printData.addAll(utf8.encode('Item            Qty   Price  Total\n'));
      printData.addAll([0x1B, 0x45, 0x00]); // Bold off
      printData.addAll(utf8.encode('-------------------------------\n'));

      // Items
      for (var item in items) {
        final itemName = (item['name'] as String).padRight(15).substring(0, 15);
        final qty = (item['quantity'] as int).toString().padRight(3);
        final price = (item['price'] as double).toStringAsFixed(2).padRight(5);
        final total = (item['total'] as double).toStringAsFixed(2).padLeft(6);
        
        printData.addAll(utf8.encode('$itemName$qty $price$total\n'));
      }

      // Separator and total
      printData.addAll(utf8.encode('-------------------------------\n'));
      printData.addAll([0x1B, 0x45, 0x01]); // Bold on
      
      final totalStr = 'TOTAL: ₹${totalAmount.toStringAsFixed(2)}';
      final totalPadding = (32 - totalStr.length) ~/ 2;
      printData.addAll([0x1B, 0x61, 0x02]); // Right align
      printData.addAll(utf8.encode(totalStr + '\n'));
      
      printData.addAll([0x1B, 0x45, 0x00]); // Bold off
      printData.addAll([0x1B, 0x61, 0x01]); // Center

      // Footer message
      printData.addAll(utf8.encode('\nThank you!\n'));
      printData.addAll(utf8.encode('Visit us again\n'));

      // Line breaks before cut
      printData.addAll(utf8.encode('\n\n\n'));

      // Cut paper
      printData.addAll([0x1D, 0x56, 0x01]); // Full cut

      // Send to printer
      _connection!.output.add(Uint8List.fromList(printData));
      await Future.delayed(const Duration(milliseconds: 500));

      print('[v0] Invoice printed successfully');
      return true;
    } catch (e) {
      _errorMessage = 'Print failed: $e';
      print('[v0] Print error: $e');
      notifyListeners();
      return false;
    }
  }

  // Disconnect printer
  Future<void> disconnectPrinter() async {
    try {
      if (_connection != null) {
        await _connection?.close();
      }
      _isConnected = false;
      _connectedPrinter = null;
      _errorMessage = null;
      print('[v0] Disconnected from printer');
      notifyListeners();
    } catch (e) {
      print('[v0] Error disconnecting: $e');
    }
  }

  // Clear saved printer
  Future<void> clearSavedPrinter() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('saved_printer');
      _connectedPrinter = null;
      print('[v0] Cleared saved printer');
      notifyListeners();
    } catch (e) {
      print('[v0] Error clearing saved printer: $e');
    }
  }

  @override
  void dispose() {
    disconnectPrinter();
    super.dispose();
  }
}
